import math

import cv2
import numpy as np
import matplotlib.pyplot as plt

# -------------------------------
# 이미지 읽기
# -------------------------------
image = cv2.imread('Lena.png')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# -------------------------------
# (1) Unsharp Mask (예시 코드 방식)
# -------------------------------
KSIZE = 11
ALPHA = 1.5

kernel = cv2.getGaussianKernel(KSIZE, 0)
kernel = -ALPHA * kernel @ kernel.T
kernel[KSIZE//2, KSIZE//2] += 1 + ALPHA

unsharp = cv2.filter2D(gray, -1, kernel)



# -------------------------------
# (2) Sobel Filter
# -------------------------------
sobel_x = cv2.Sobel(unsharp, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(unsharp, cv2.CV_64F, 0, 1, ksize=3)

sobel = cv2.magnitude(sobel_x, sobel_y)
sobel = np.uint8(np.clip(sobel, 0, 255))

# -------------------------------
# (3) Gabor Filter
# -------------------------------
kernel_gabor = cv2.getGaborKernel((21,21), 5, 1, 10, 1, 0, cv2.CV_32F)
kernel_gabor /= math.sqrt((kernel_gabor * kernel_gabor).sum())
gabor = cv2.filter2D(unsharp, cv2.CV_8UC3, kernel_gabor)

# -------------------------------
# (4) Threshold + Trackbar
# -------------------------------
def nothing(x):
    pass

cv2.namedWindow("Threshold Compare")
cv2.createTrackbar("TH", "Threshold Compare", 50, 255, nothing)

while True:
    th = cv2.getTrackbarPos("TH", "Threshold Compare")

    _, sobel_th = cv2.threshold(sobel, th, 255, cv2.THRESH_BINARY)
    _, gabor_th = cv2.threshold(gabor, th, 255, cv2.THRESH_BINARY)

    diff = cv2.absdiff(sobel_th, gabor_th)

    cv2.imshow("Threshold Compare", diff)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cv2.destroyWindow("Threshold Compare")

# -------------------------------
# (5) Opening & Closing
# -------------------------------
kernel_m = np.ones((5,5), np.uint8)

opening = cv2.morphologyEx(diff, cv2.MORPH_OPEN, kernel_m)
closing = cv2.morphologyEx(diff, cv2.MORPH_CLOSE, kernel_m)

# -------------------------------
# 결과 출력
# -------------------------------
plt.figure(figsize=(10,6))

plt.subplot(231)
plt.title("Original")
plt.imshow(gray, cmap='gray')
plt.axis('off')

plt.subplot(232)
plt.title("Unsharp")
plt.imshow(unsharp, cmap='gray')
plt.axis('off')

plt.subplot(233)
plt.title("Sobel")
plt.imshow(sobel, cmap='gray')
plt.axis('off')

plt.subplot(234)
plt.title("Gabor")
plt.imshow(gabor, cmap='gray')
plt.axis('off')

plt.subplot(235)
plt.title("Opening")
plt.imshow(opening, cmap='gray')
plt.axis('off')

plt.subplot(236)
plt.title("Closing")
plt.imshow(closing, cmap='gray')
plt.axis('off')

plt.tight_layout()
plt.show()